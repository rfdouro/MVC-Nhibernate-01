commonWidgetTests( "tabs", {
	defaults: {
		active: null,
		collapsible: false,
		disabled: false,
		event: "click",
		fx: null,

		// callbacks
		activate: null,
		beforeActivate: null,
		beforeLoad: null,
		create: null,
		load: null
	}
});
